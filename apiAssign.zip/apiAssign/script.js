$(document).ready(function () {
    var url = "https://reqres.in/api/users?page=1&per_page=12";
    const nbUserPerRow = 4;
    $.get(url, function (response) {
        for (var i = 0; i < response.data.length;) {
            let row = $("<tr/>");
            for (var j = 0; j < nbUserPerRow; j++) {
                let user = response.data[i];

                let img = $("<img/>").attr("src", response.data[i].avatar);
                let colName = $("<td/>").html(user.first_name + " " + user.last_name);
                let colAvatar = $("<td/>").append(img);
                let colMail = $("<td/>").html(user.email);

                row.append(colAvatar).append(colName).append(colMail);
                i++
            }
            $("#wrapper > table").append(row);
        }
        $.get(url, function(response) {
            $("td").css("padding","8px");
        })
    });
});